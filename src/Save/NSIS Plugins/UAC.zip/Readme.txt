Language support:
-----------------
If the plugin is built with FEAT_CUSTOMRUNASDLG_TRANSLATE, 
you can extract a file named UAC.LNG to $pluginsdir. 
It is a ini file with the following sections:

[MyRunAsCfg]
;Set to 1 to disable the radio button
DisableCurrUserOpt=
;Set to 1 to hide the radio button
HideCurrUserOpt=

[MyRunAsStrings]
DlgTitle=Hello There!
HelpText=Just do your thing!
;Label for current user radio button, %s is replaced with result of GetUserNameEx(NameSamCompatible,...)
OptCurrUser=Self service (%s)
OptOtherUser=Run as someone:
UserName=Who:
Pwd=PIN:
OK=Okey!
Cancel=No Way
