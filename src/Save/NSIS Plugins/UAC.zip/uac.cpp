//Copyright (C) 2007 Anders Kjersem. Licensed under the zlib/libpng license, see License.txt for details.
/*
UAC plugin for NSIS
===================
Compiled with VC6+PlatformSDK (StdCall & MinimizeSize)


Todo:
-----
�Check if secondary logon service is running in SysElevationPresent() on NT5
�Use IsUserAnAdmin? MAKEINTRESOURCE(680) export on 2k //http://forums.winamp.com/showthread.php?s=&threadid=195020
�AllowSetForegroundWindow
�Use RPC instead of WM_COPYDATA for IPC
�Autodetect "best" default admin user in MyRunAs
�Use ChangeWindowMessageFilter so we can get >WM_USER msg success feedback and possibly fill the log with detailprints
�Hide IPC window inside inner instance window? (Could this add unload problems?)
�CREATE_PRESERVE_CODE_AUTHZ_LEVEL? http://msdn2.microsoft.com/en-us/library/ms684863.aspx
�UpdateProcThreadAttribute?
�Consent UI on XP ?
�All langs in single file; [MyRunAsStrings]>LangSections != 0 then load strings from [langid] sections


History:
--------
v0.0.6c - 20071014 (AndersK)
	+Check for and split up "domain\user" style input in RunAs.cpp for CreateProcessWithLogonW
	*Added a ugly hack to trick messagebox'es in .OnInit to appear correctly on Vista (Thanks Clammerz)

v0.0.6b - 20070523 (AndersK)
	*Fixed showwindow flag (Thanks for the help kichik)

v0.0.6	- 20070512 (AndersK)
	+Added basic language support for MyRunAs dialog.

v0.0.5e	- 20070509 (AndersK)
	*Fixed detection of UAC mode?
	+IPC window is visible (but offscreen) during elevation to help with SetForegroundWindow/Focus problems

v0.0.5d - 20070324 (AndersK)
	*Fixed stupid IsAdmin bug

v0.0.5c	- 20070304 (AndersK)
	*_IsAdmin now uses CheckTokenMembership if it exists ( MSKB:Q118626 / http://blogs.msdn.com/larryosterman/archive/2007/03/14/why-does-kb-118626-use-accesscheck-to-check-if-you-re-a-member-of-the-administrators-group.aspx )	

v0.0.5b	- 20070301 (AndersK)
	*Fixed ExecCodeSegment (Thread now calls CoInitialize)

v0.0.5	- 20070228 (AndersK)
	+Added ExecCodeSegment (You can now call ANY code in the context of the original user)

v0.0.4b	- 20070226 (AndersK)
	*Fixed (My)RunAs font (http://blogs.msdn.com/oldnewthing/archive/2005/02/04/366987.aspx)
  
v0.0.4	- 20070225 (AndersK)
	+Added (My)RunAs dialog, used on Vista when running as LUA with UAC off
	+Always uses /NCRC for elevated instance
	*Now compiles as UNICODE (Untested, no UnicodeNSIS to test on)

v0.0.3	- 20070224 (AndersK)
	+Added Exec/ExecWait
	+Added Verb & ShowWindow support for ShellExec[Wait]

v0.0.2	- 20070219 (AndersK)
	+Added ShellExecWait
	*IPC srv wnd now has its own thread and msg loop
	*Removed CRT dependency
	*Hopefully loads on Win95 now

v0.0.1	- 20070215 (AndersK)
	*Initial release

Notes:
------
Primary integrity levels
Name					SID				RID 
Low Mandatory Level		S-1-16-4096		0x1000
Medium Mandatory Level	S-1-16-8192		0x2000
High Mandatory Level	S-1-16-12288	0x3000
System Mandatory Level	S-1-16-16384	0x4000
*/

#define UAC_INITIMPORTS
#include "UAC.h"
#include "NSISUtil.h"
using namespace NSIS;
NSISUTIL_INIT();


#define ERRAPP_BADIPCSRV (0x20000000|1)
#define SW_INVALID ((WORD)-1)

enum _IPCSRVWNDMSG {
	IPC_GETEXITCODE=WM_USER, //Get exit-code of the process spawned by the last call to ExecWait/ShellExecWait
	IPC_ELEVATEAGAIN,
	IPC_GETSRVPID,

	IPC_EXECCODESEGMENT,//wp:pos | lp:hwnd | returns ErrorCode+1
};

enum _COPYDATAID {
	CDI_SHEXEC=666,//returns WindowsErrorCode+1
};

typedef struct {
	HWND hwnd;
	bool Wait;
	bool UseCreateProcess;
	WORD ShowMode;	
	NSISCH*strExec;
	NSISCH*strParams;
	NSISCH*strWorkDir;
	NSISCH*strVerb;
	NSISCH buf[ANYSIZE_ARRAY];
} IPC_SHEXEC;


typedef struct {
	HINSTANCE	hInstance;
	HWND		hSrvIPC;
	BYTE		DllRef;
	bool		UseIPC;
	
	//IPC Server stuff
	HANDLE		threadIPC;
	bool		ElevateAgain;
	DWORD		LastWaitExitCode;//Exit code of process started from last call to ExecWait/ShellExecWait
	NSIS::extra_parameters*pXParams;
	//DelayLoadedModules:
	HMODULE		hModAdvAPI;
} GLOBALS;

GLOBALS g={0};

void StopIPCSrv();
DWORD _GetElevationType(TOKEN_ELEVATION_TYPE*pTokenElevType);
__forceinline NSISCH* GetIPCWndClass() { return _T("NSISUACIPC"); }

UINT_PTR StrToUInt(LPTSTR s,bool ForceHEX=false,BOOL*pFoundBadChar=0) {
	UINT_PTR v=0;
	BYTE base=ForceHEX?16:10;	
	if (pFoundBadChar)*pFoundBadChar=false;
	if (!ForceHEX&&*s=='0'&&((*(s=CharNext(s)))&~0x20)=='X'&&(s=CharNext(s)))base=16;
	for (TCHAR c=*s; c; c=*(s=CharNext(s)) ) {
		if (c >= _T('0') && c <= _T('9')) c-='0';
		else if (base==16 && (c & ~0x20) >= 'A' && (c & ~0x20) <= 'F') c=(c & 7) +9;
		else {
			if (pFoundBadChar /*&& c!=' '*/)*pFoundBadChar=true;
			break;
		}
		v*=base;v+=c;
	}
	return v;
}

bool StrContainsWhiteSpace(LPCTSTR s) {
	if (s) {while(*s && *s>_T(' '))++s;if (*s)return true;}return false;
}

LPTSTR FindExePathEnd(LPTSTR p) {//TODO: MBCS safe?
	if (*p=='"' && *(++p)) {while(*p && *p!='"')++p;if (*p)++p;else return 0;}else if (*p!='/')while(*p && *p!=' ')++p;
	return p;
}

DWORD DllSelfAddRef() {
	NSISCH buf[MAX_PATH*5];//Lets hope $pluginsdir is shorter than this, only special builds could break this
	DWORD len=GetModuleFileName(g.hInstance,buf,MAX_PATH*5);
	if (len && len<MAX_PATH*5) if (LoadLibrary(buf)) {
		if (!g.DllRef)g.DllRef++;
		return NO_ERROR;
	}
	ASSERT(!"DllSelfAddRef failed!");
	return ERROR_BUFFER_OVERFLOW;
}
__forceinline DWORD MaintainDllSelfRef() { return g.DllRef?DllSelfAddRef():NO_ERROR;}//Call this from every exported function to prevent NSIS from unloading our plugin

DWORD SendIPCMsg(UINT Msg,WPARAM wp,LPARAM lp,DWORD_PTR&MsgRet,DWORD tout=(1000*3)) {
	if (tout==INFINITE) {//BUGFIX: SendMessageTimeout(...,INFINITE,...) seems to be broken, SendMessageTimeout(...,SMTO_NORMAL,0,..) seems to work but why take the chance
		MsgRet=SendMessage(g.hSrvIPC,Msg,wp,lp);return NO_ERROR;
	}
	if (SendMessageTimeout(g.hSrvIPC,Msg,wp,lp,SMTO_NORMAL,tout,&MsgRet))return NO_ERROR;
	return (tout=GetLastError())?tout:ERROR_TIMEOUT;//using tout as temporary here
}

void _Unload() {
	StopIPCSrv();
	if (g.DllRef) {
		g.DllRef=0;
		FreeLibrary(g.hInstance);
		//Why bother?>>>FreeLibrary(g.hModAdvAPI);
	}
}

DWORD DelayLoadGetProcAddr(void**ppProc,HMODULE hLib,LPCSTR Export) {
	ASSERT(ppProc && hLib && Export);
	if (!*ppProc) {
		*ppProc=GetProcAddress(hLib,Export);
		if (!*ppProc)return GetLastError();
	}
	return NO_ERROR;
}

DWORD DelayLoadDlls() {
	//NOTE: Not using UNICODE/TCHAR to save a couple of bytes
#ifdef UNICODE
#define __DLD_FUNCSUFFIX "W"
#else
#define __DLD_FUNCSUFFIX "A"
#endif
	if (!g.hModAdvAPI) {
		unsigned o;
		DWORD ec;
		struct {HMODULE*pMod;LPCSTR DllName;} dld[]={
			{&g.hModAdvAPI,"AdvAPI32"},
			{0}
		};
		for (o=0;dld[o].pMod;++o)if (!(*dld[o].pMod=LoadLibraryA(dld[o].DllName)))return GetLastError();
		struct {HMODULE hMod;void**ppProc;LPCSTR Export;bool Optional;} dldprocs[]={
			{GetModuleHandle(_T("USER32")),(void**)&_AllowSetForegroundWindow,"AllowSetForegroundWindow"},
			{g.hModAdvAPI,(void**)&_OpenProcessToken,			"OpenProcessToken"},
			{g.hModAdvAPI,(void**)&_OpenThreadToken,			"OpenThreadToken"},
			{g.hModAdvAPI,(void**)&_GetTokenInformation,		"GetTokenInformation"},
			{g.hModAdvAPI,(void**)&_AllocateAndInitializeSid,	"AllocateAndInitializeSid"},
			{g.hModAdvAPI,(void**)&_FreeSid,					"FreeSid"},
			{g.hModAdvAPI,(void**)&_EqualSid,					"EqualSid"},
			{g.hModAdvAPI,(void**)&_CheckTokenMembership,		"CheckTokenMembership",true},
			#ifdef FEAT_CUSTOMRUNASDLG
			{g.hModAdvAPI,(void**)&_GetUserName,			"GetUserName" __DLD_FUNCSUFFIX},
			{g.hModAdvAPI,(void**)&_CreateProcessWithLogonW,"CreateProcessWithLogonW"},
			{LoadLibraryA("SECUR32"),(void**)&_GetUserNameEx,"GetUserNameEx" __DLD_FUNCSUFFIX,true},//We never free this library
			#endif
			{0}
		};
		for (o=0;dldprocs[o].hMod;++o)if (ec=DelayLoadGetProcAddr(dldprocs[o].ppProc,dldprocs[o].hMod,dldprocs[o].Export) && !dldprocs[o].Optional) {
			TRACEF("DelayLoadDlls failed to find %s in %X\n",dldprocs[o].Export,dldprocs[o].hMod);
			return ec;
		}
	}
	return NO_ERROR;
#undef __DLD_FUNCSUFFIX
}

DWORD _Exec(HWND hwnd,NSISCH*Verb,NSISCH*Exec,NSISCH*Params,NSISCH*WorkDir,WORD ShowWnd,bool Wait,bool UseCreateProcess) {
	SHELLEXECUTEINFO sei={sizeof(SHELLEXECUTEINFO)};
	sei.hwnd		=hwnd;
	sei.nShow		=(ShowWnd!=SW_INVALID)?ShowWnd:SW_NORMAL;
	sei.fMask		=SEE_MASK_FLAG_DDEWAIT;
	sei.lpFile		=(Exec&&*Exec)			?Exec:0;
	sei.lpParameters=(Params&&*Params)		?Params:0;
	sei.lpDirectory	=(WorkDir&&*WorkDir)	?WorkDir:0;
	sei.lpVerb		=(Verb&&*Verb)			?Verb:0;
	TRACEF("_Exec:%X|%s|%s|%s|wait=%d useCreateProc=%d ShowWnd=%d useShowWnd=%d\n",hwnd,Exec,Params,WorkDir,Wait,UseCreateProcess,ShowWnd,ShowWnd!=SW_INVALID);
	if (UseCreateProcess) {
		STARTUPINFO si={sizeof(STARTUPINFO)};
		si.wShowWindow=sei.nShow;
		if (ShowWnd!=SW_INVALID)si.dwFlags|=STARTF_USESHOWWINDOW;
		PROCESS_INFORMATION pi;
		const NSISCH*Q=((*Exec!='"')&&(*Params)&& StrContainsWhiteSpace(Exec)) ? _T("\"") : _T("");//Add extra quotes to program part of commandline?
		const DWORD len=(*Q?2:0)+lstrlen(Exec)+1+lstrlen(Params)+1;
		NSISCH*buf=(NSISCH*)NSIS::MemAlloc(len*sizeof(NSISCH));
		//Build string for CreateProcess, "[Q?]<Exec>[Q?]<SpaceOrTerminate><Params>"
		wsprintf(buf,_T("%s%s%s%s%s"),Q,Exec,Q,((*Params)?_T(" "):_T("")),Params);
		TRACEF("_Exec: calling CreateProcess with >%s< in >%s< addedQ=%d show=%u\n",buf,sei.lpDirectory,*Q,sei.nShow);
		if (!CreateProcess(0,buf,0,0,false,0,0,sei.lpDirectory,&si,&pi)) {
			const ec=GetLastError();
			TRACEF("_Exec>CreateProcess failed with error %u\n",ec);
			return ec;
		}
		CloseHandle(pi.hThread);
		if (Wait) sei.hProcess=pi.hProcess; else CloseHandle(pi.hProcess);
	}
	else {
		if (Wait)sei.fMask|=SEE_MASK_NOCLOSEPROCESS;
		if (!ShellExecuteEx(&sei))return GetLastError();
	}
	if (Wait) {
		WaitForSingleObject(sei.hProcess,INFINITE);
		GetExitCodeProcess(sei.hProcess,&g.LastWaitExitCode);
		CloseHandle(sei.hProcess);
	}
	return NO_ERROR;
}

WORD GetShowWndCmdFromStr(NSISCH*s) {
	//NOTE: Little used modes are still supported, just not with strings, you must use the actual number or ${SW_xx} defines from WinMessages.h
	struct {NSISCH*id;WORD cmd;} swcm[]={
		{_T("SW_HIDE"),				SW_HIDE},
		{_T("SW_SHOW"),				SW_SHOW},
		{_T("SW_RESTORE"),			SW_RESTORE},
		{_T("SW_MAXIMIZE"),			SW_MAXIMIZE},
		{_T("SW_MINIMIZE"),			SW_MINIMIZE},
			{_T("SW_MAX"),			SW_MAXIMIZE},
			{_T("SW_MIN"),			SW_MINIMIZE},
		{_T("SW_SHOWNORMAL"),		SW_SHOWNORMAL},
		//{_T("SW_NORMAL"),			SW_NORMAL},
		//{_T("SW_SHOWMINIMIZED"),	SW_SHOWMINIMIZED},
		//{_T("SW_SHOWMAXIMIZED"),	SW_SHOWMAXIMIZED},
		//{_T("SW_SHOWNOACTIVATE"),	SW_SHOWNOACTIVATE},
		//{_T("SW_SHOWNA"),			SW_SHOWNA},
		//{_T("SW_SHOWMINNOACTIVE"),	SW_SHOWMINNOACTIVE},
		//{_T("SW_SHOWDEFAULT"),		SW_SHOWDEFAULT},
		//{_T("SW_FORCEMINIMIZE"),	SW_FORCEMINIMIZE},
		{0}
	};
	for (int i=0; swcm[i].id; ++i)if (0==lstrcmpi(s,swcm[i].id))return swcm[i].cmd;
	return SW_INVALID;
}

void HandleExecExport(bool CreateProc,bool Wait,HWND&hwndNSIS,int&StrSize,NSISCH*&Vars,stack_t**&StackTop,NSIS::extra_parameters*pXParams) {
	DWORD ec=NO_ERROR,ForkExitCode=ERROR_INVALID_FUNCTION;
	UINT cch=0,cbStruct;
	WORD ShowWnd;
	IPC_SHEXEC*pISE=0;
	stack_t* const pSIVerb=CreateProc?0:StackPop();//Only ShellExec supports verb's
	stack_t* const pSIShowWnd	=StackPop();
	stack_t* const pSIExec		=StackPop();
	stack_t* const pSIParams	=StackPop();
	stack_t* const pSIWorkDir	=StackPop();

	if (ec=MaintainDllSelfRef())goto ret;
	if (!pSIExec || !pSIParams || !pSIWorkDir || !pSIShowWnd || (!pSIVerb && !CreateProc)) {
		TRACEF("If you see this you probably forgot that all parameters are required!\n");
		ec=ERROR_INVALID_PARAMETER;
		goto ret;
	}
	ShowWnd=GetShowWndCmdFromStr(pSIShowWnd->text);
	if (ShowWnd==SW_INVALID && *pSIShowWnd->text) {
		BOOL BadCh;
		ShowWnd=StrToUInt(pSIShowWnd->text,false,&BadCh);
		if (BadCh)ShowWnd=SW_INVALID;
	}
	TRACEF("ipc=%X\n",g.UseIPC);
	if (!g.UseIPC) {//No IPC Server, we are not elevated with UAC
		ec=_Exec(hwndNSIS,pSIVerb?pSIVerb->text:0,pSIExec->text,pSIParams->text,pSIWorkDir->text,ShowWnd,Wait,CreateProc);
		if (Wait)ForkExitCode=g.LastWaitExitCode;
		goto ret;
	}	
	cch+=lstrlen(pSIExec->text)+1;
	cch+=lstrlen(pSIParams->text)+1;
	cch+=lstrlen(pSIWorkDir->text)+1;
	if (pSIVerb)cch+=lstrlen(pSIVerb->text)+1;
	cbStruct=FIELD_OFFSET(IPC_SHEXEC,buf[cch]);
	pISE=(IPC_SHEXEC*)NSIS::MemAlloc(cbStruct);
	if (!pISE)ec=GetLastError();
	if (!ec) {
		DWORD_PTR MsgRet;
		pISE->hwnd		=hwndNSIS;
		pISE->Wait		=Wait;
		pISE->ShowMode	=ShowWnd;
		pISE->UseCreateProcess=CreateProc;
		//Just offsets at this point
		pISE->strExec	=(NSISCH*)0;
		pISE->strParams	=(NSISCH*)(lstrlen(pSIExec->text)	+pISE->strExec+1);
		pISE->strWorkDir=(NSISCH*)(lstrlen(pSIParams->text)	+pISE->strParams+1);
		pISE->strVerb=	 (NSISCH*)(lstrlen(pSIWorkDir->text)+pISE->strWorkDir+1);
		lstrcpy(pISE->buf,pSIExec->text);
		lstrcpy(&pISE->buf[(DWORD_PTR)pISE->strParams],	pSIParams->text);
		lstrcpy(&pISE->buf[(DWORD_PTR)pISE->strWorkDir],pSIWorkDir->text);
		if (pSIVerb)lstrcpy(&pISE->buf[(DWORD_PTR)pISE->strVerb],	pSIVerb->text);
		COPYDATASTRUCT cds;
		cds.dwData=CDI_SHEXEC;
		cds.cbData=cbStruct;
		cds.lpData=pISE;

		ASSERT(_AllowSetForegroundWindow);
		if (!SendIPCMsg(IPC_GETSRVPID,0,0,MsgRet) && MsgRet && _AllowSetForegroundWindow)_AllowSetForegroundWindow(MsgRet);

		if (!(ec=SendIPCMsg(WM_COPYDATA,(WPARAM)hwndNSIS,(LPARAM)&cds,MsgRet,Wait?(INFINITE):(1000*10) )))ec=MsgRet-1;
		TRACEF("HandleExecExport: IPC returned %X, ec=%d\n",MsgRet,ec);
		if (Wait && NO_ERROR==ec) {
			ec=SendIPCMsg(IPC_GETEXITCODE,0,0,ForkExitCode);
			TRACEF("HandleExecExport(Wait): Spawned process exit code=%d",ForkExitCode);
		}
	}
ret:
	NSIS::MemFree(pISE);
	StackFreeItem(pSIShowWnd);
	StackFreeItem(pSIExec);
	StackFreeItem(pSIParams);
	StackFreeItem(pSIWorkDir);
	StackFreeItem(pSIVerb);
	SetVarUINT(INST_0,ec);
	if (ec)SetErrorFlag(pXParams);
	if (Wait)SetVarUINT(INST_1,ForkExitCode);
}


/*** Exec
Notes:
		� ErrorFlag is also set on error
STACK:	<ShowWindow> <File> <Parameters> <WorkingDir>
Return:	windows error code in r0, 0 on success
*/
NSISEXPORT(Exec   ,hwndNSIS,StrSize,Vars,StackTop,pXParams) {
	HandleExecExport(true,false,hwndNSIS,StrSize,Vars,StackTop,pXParams);
}}

/*** ExecWait
Notes:
		� ErrorFlag is also set on error
STACK:	<ShowWindow> <File> <Parameters> <WorkingDir>
Return:	
		r0: windows error code, 0 on success
		r1: exitcode of new process 
*/
NSISEXPORT(ExecWait   ,hwndNSIS,StrSize,Vars,StackTop,pXParams) {
	HandleExecExport(true,true,hwndNSIS,StrSize,Vars,StackTop,pXParams);
}}

/*** ShellExec
Notes:
		� ErrorFlag is also set on error
STACK:	<Verb> <ShowWindow> <File> <Parameters> <WorkingDir>
Return:	windows error code in r0, 0 on success
*/
NSISEXPORT(ShellExec   ,hwndNSIS,StrSize,Vars,StackTop,pXParams) {
	HandleExecExport(false,false,hwndNSIS,StrSize,Vars,StackTop,pXParams);
}}

/*** ShellExecWait
Notes:
		� ErrorFlag is also set on error
STACK:	<Verb> <ShowWindow> <File> <Parameters> <WorkingDir>
Return:	
		r0: windows error code, 0 on success
		r1: exitcode of new process 
*/
NSISEXPORT(ShellExecWait   ,hwndNSIS,StrSize,Vars,StackTop,pXParams) {
	HandleExecExport(false,true,hwndNSIS,StrSize,Vars,StackTop,pXParams);
}}


bool _SupportsUAC(bool VersionTestOnly=false) {
	OSVERSIONINFO ovi={sizeof(ovi)};
	if (!GetVersionEx(&ovi)) {
		ASSERT(!"_SupportsUAC>GetVersionEx");
		return false;
	}
	if (VersionTestOnly)return ovi.dwMajorVersion>=6;
	TOKEN_ELEVATION_TYPE tet;
	if (ovi.dwMajorVersion>=6 && _GetElevationType(&tet)==NO_ERROR) {
		TRACEF("_SupportsUAC tet=%d, returning %d\n",tet,(tet!=TokenElevationTypeDefault && tet!=NULL));
		return tet!=TokenElevationTypeDefault && tet!=NULL;
	}
	DBGONLY(TRACEF("_SupportsUAC returning false! ver=%d _GetElevationType.ret=%u\n",ovi.dwMajorVersion,_GetElevationType(&tet)));
	return false;
	//return ovi.dwMajorVersion>=6 && _GetElevationType(&tet)==NO_ERROR && tet!=TokenElevationTypeDefault && tet!=NULL;
}

DWORD _GetElevationType(TOKEN_ELEVATION_TYPE*pTokenElevType) {
	DWORD ec=ERROR_ACCESS_DENIED;
	HANDLE hToken=0;
	DWORD RetLen;
	if (!pTokenElevType)return ERROR_INVALID_PARAMETER;
	if (ec=DelayLoadDlls())return ec;
	*pTokenElevType=(TOKEN_ELEVATION_TYPE)NULL;
	if (!_SupportsUAC(true))return NO_ERROR;
	if (!_OpenProcessToken(GetCurrentProcess(),TOKEN_QUERY,&hToken))goto dieLastErr;
	if (!_GetTokenInformation(hToken,(_TOKEN_INFORMATION_CLASS)TokenElevationType,pTokenElevType,sizeof(TOKEN_ELEVATION_TYPE),&RetLen))goto dieLastErr;
	SetLastError(NO_ERROR);
dieLastErr:
	ec=GetLastError();
	CloseHandle(hToken);
	TRACEF("_GetElevationType ec=%u type=%d\n",ec,*pTokenElevType);
	return ec;
}


DWORD GetSysVer(bool Major=true) {
	OSVERSIONINFO ovi={sizeof(ovi)};
	if (!GetVersionEx(&ovi))return 0;
	return Major?ovi.dwMajorVersion:ovi.dwMinorVersion;
}

bool _IsUACEnabled() {
	HKEY hKey;
	bool ret=false;
	if (GetSysVer()>=6 && NO_ERROR==RegOpenKeyEx(HKEY_LOCAL_MACHINE,_T("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System"),0,KEY_READ,&hKey)) {
		DWORD val,type,size=sizeof(DWORD);
		if (NO_ERROR==RegQueryValueEx(hKey,_T("EnableLUA"),0,&type,(LPBYTE)&val,&size) && type==REG_DWORD && val!=0) ret=true;
		RegCloseKey(hKey);
	}
	return ret;
}

//This will return false on Vista if UAC is off
bool SysElevationPresent() { 
	const DWORD vmaj=GetSysVer();
	ASSERT(vmaj<=6 && vmaj>=4);
	if (vmaj==5)return true;//TODO:Check if secondary logon service is running?
	if (vmaj>5) {
		return _IsUACEnabled();
	}	
	return false;
}

inline bool SysSupportsRunAs() { return GetSysVer()>=5;}
/*
bool SysSupportsRunAs() {
#ifdef FEAT_CUSTOMRUNASDLG //NT5+ (Only used on Vista without UAC)
	OSVERSIONINFO ovi={sizeof(ovi)};
	if (!GetVersionEx(&ovi))return false;
	return ovi.dwMajorVersion>=5;
#else
	return _SupportsUAC();//Vista without UAC
#endif
}*/




bool _IsAdmin() {
#ifdef BUILD_XPTEST
	static int _dbgOld=-1;
	unsigned _dbg=(unsigned)FindExePathEnd(GetCommandLine());
	if (_dbgOld==-1){_dbg=(_dbg && *((TCHAR*)_dbg))?MessageBoxA(0,"Debug: Pretend to be admin?",GetCommandLine(),MB_YESNOCANCEL):IDCANCEL;} else _dbg=_dbgOld;_dbgOld=_dbg;TRACEF("_IsAdmin=%d|%d\n",_dbg,_dbg==IDYES);
	if (_dbg!=IDCANCEL){SetLastError(0);return _dbg==IDYES;}
#endif
	BOOL isAdmin=false;
	DWORD ec;
	OSVERSIONINFO ovi={sizeof(ovi)};	
	if (!GetVersionEx(&ovi))return false;
	if (VER_PLATFORM_WIN32_NT>ovi.dwPlatformId) {//Not NT
		SetLastError(NO_ERROR);
		return true;
	}
	if (ec=DelayLoadDlls()) {
		SetLastError(ec);
		return false;
	}
	ASSERT(_OpenThreadToken&&_OpenProcessToken&&_AllocateAndInitializeSid&&_EqualSid&&_FreeSid);
	HANDLE hToken;
	if (_OpenThreadToken(GetCurrentThread(),TOKEN_QUERY,FALSE,&hToken) || _OpenProcessToken(GetCurrentProcess(),TOKEN_QUERY,&hToken)) {
		SID_IDENTIFIER_AUTHORITY SystemSidAuthority = SECURITY_NT_AUTHORITY;
		PSID psid=0;
		if (_AllocateAndInitializeSid(&SystemSidAuthority,2,SECURITY_BUILTIN_DOMAIN_RID,DOMAIN_ALIAS_RID_ADMINS,0,0,0,0,0,0,&psid)) {
			if (_CheckTokenMembership) {
				if (!_CheckTokenMembership(0,psid,&isAdmin))isAdmin=false;
			}
			else {
				DWORD cbTokenGrps;
				if (!_GetTokenInformation(hToken,TokenGroups,0,0,&cbTokenGrps)&&GetLastError()==ERROR_INSUFFICIENT_BUFFER) {
					TOKEN_GROUPS*ptg=0;
					if (ptg=(TOKEN_GROUPS*)NSIS::MemAlloc(cbTokenGrps)) {
						if (_GetTokenInformation(hToken,TokenGroups,ptg,cbTokenGrps,&cbTokenGrps)) {
							for (UINT i=0; i<ptg->GroupCount;i++)if (_EqualSid(ptg->Groups[i].Sid,psid))isAdmin=true;
						}
						NSIS::MemFree(ptg);
					}
				}
			}			
			_FreeSid(psid);
		}
		CloseHandle(hToken);
	}
	if (isAdmin) {//UAC admin with split token check
		if (_SupportsUAC()) {
			TOKEN_ELEVATION_TYPE tet;
			if (_GetElevationType(&tet) || tet==TokenElevationTypeLimited)isAdmin=false;
		}
		else SetLastError(NO_ERROR);
	}
	return isAdmin!=FALSE;
}


LRESULT CALLBACK IPCSrvWndProc(HWND hwnd,UINT uMsg,WPARAM wp,LPARAM lp) {
	switch(uMsg) {
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	case WM_CLOSE:
		return DestroyWindow(hwnd);
	case WM_COPYDATA:
		if (lp) {
			const COPYDATASTRUCT*pCDS=(COPYDATASTRUCT*)lp;
			if (pCDS->dwData==CDI_SHEXEC && pCDS->lpData) {
				if ( pCDS->cbData<sizeof(IPC_SHEXEC) )break;
				g.LastWaitExitCode=ERROR_INVALID_FUNCTION;
				IPC_SHEXEC& ise=*((IPC_SHEXEC*)pCDS->lpData);
				SetForegroundWindow(ise.hwnd);
				DWORD ec=_Exec(
				ise.hwnd,
				&ise.buf[(DWORD_PTR)ise.strVerb],
				&ise.buf[(DWORD_PTR)ise.strExec],
				&ise.buf[(DWORD_PTR)ise.strParams],
				&ise.buf[(DWORD_PTR)ise.strWorkDir],
				ise.ShowMode,ise.Wait,ise.UseCreateProcess
				);
				TRACEF("IPCSrvWndProc>IPC_SHEXEC>_ShExec=%d\n",ec);
				return ec+1;
			}
		}
		break;
	case IPC_GETEXITCODE:
		return g.LastWaitExitCode;
	case IPC_ELEVATEAGAIN:
		TRACE("IPCSrvWndProc>IPC_ELEVATEAGAIN\n");
		return (g.ElevateAgain=true);
	case IPC_GETSRVPID:
		return GetCurrentProcessId();//FUCKO?
	case IPC_EXECCODESEGMENT:
		return 1+(g.pXParams?ExecuteCodeSegment(g.pXParams,wp,(HWND)lp):ERROR_INVALID_FUNCTION);
	}
	return DefWindowProc(hwnd,uMsg,wp,lp);
}

#include <objbase.h>//CoInitialize
DWORD WINAPI IPCSrvThread(LPVOID lpParameter) {
	CoInitialize(0);
	const WStyle=DBGONLY(WS_CAPTION|)WS_VISIBLE;
	const PosOffset=32700;
	MSG msg;
	WNDCLASS wc={0};
	wc.lpszClassName=GetIPCWndClass();
	wc.lpfnWndProc=IPCSrvWndProc;
	wc.hInstance=g.hInstance;
	if (!RegisterClass(&wc))goto dieLastErr;	
	if (!(g.hSrvIPC=CreateWindowEx(WS_EX_TOOLWINDOW DBGONLY(&~WS_EX_TOOLWINDOW),
		GetIPCWndClass(),
		DBGONLY(_T("Debug: NSIS.UAC")+)0,
		WStyle,
		-PosOffset DBGONLY(+PosOffset),-PosOffset DBGONLY(+PosOffset),DBGONLY(150+)1,DBGONLY(10+)1,
		0,0,wc.hInstance,0
		)))goto dieLastErr;		
	TRACEF("IPCSrv=%X\n",g.hSrvIPC);
	while (GetMessage(&msg,0,0,0)>0)DispatchMessage(&msg);
	SetLastError(NO_ERROR);
dieLastErr:
	CoUninitialize();
	return g.LastWaitExitCode=GetLastError();
}

DWORD InitIPC(NSIS::extra_parameters*pXParams) {
	if (g.threadIPC)return NO_ERROR;
	DWORD tid;
	ASSERT(!g.pXParams && pXParams);
	g.pXParams=pXParams;
	g.threadIPC=CreateThread(0,0,IPCSrvThread,0,0,&tid);
	if (g.threadIPC) {
		while(!g.hSrvIPC && !g.LastWaitExitCode)Sleep(20);
		return g.hSrvIPC?NO_ERROR:g.LastWaitExitCode;
	}
	return GetLastError();
}

void StopIPCSrv() {
	if (g.threadIPC) {
		TRACEF("StopIPCSrv h=%X \n",g.hSrvIPC);
		if ( GetSysVer()>=5 )
		{
			//WINBUGFIX: This ugly thing solves the problem of messagebox'es in .OnInit appearing behind other windows in Vista
			HWND hack=CreateWindowEx(WS_EX_TRANSPARENT|WS_EX_LAYERED,_T("Button"),NULL,NULL,0,0,0,0,NULL,NULL,NULL,0);
			ShowWindow(hack,SW_SHOW);
			SetForegroundWindow(hack);
			DestroyWindow(hack);		
		}
		PostMessage(g.hSrvIPC,WM_CLOSE,0,0);
		WaitForSingleObject(g.threadIPC,INFINITE);
		CloseHandle(g.threadIPC);
		UnregisterClass(GetIPCWndClass(),g.hInstance);//DLL can be loaded more than once, so make sure RegisterClass doesn't fail
		g.hSrvIPC=0;
		g.threadIPC=0;
	}
}

DWORD ForkSelf(DWORD&ForkExitCode,NSIS::extra_parameters*pXParams) {
	DWORD ec=ERROR_ACCESS_DENIED;
	SHELLEXECUTEINFO sei={sizeof(sei)};
	STARTUPINFO startInfo={sizeof(STARTUPINFO)};
	LPTSTR pszExePathBuf=0;
	LPTSTR pszParamBuf=0;
	LPTSTR p,pCL=GetCommandLine();
	UINT len;
	bool ShExecRunAs=true;

	ASSERT(pXParams);
	
	GetStartupInfo(&startInfo);
	if (ec=InitIPC(pXParams))goto ret;
	ASSERT(IsWindow(g.hSrvIPC));
	sei.nShow=(startInfo.dwFlags&STARTF_USESHOWWINDOW)?startInfo.wShowWindow:SW_SHOWNORMAL;
	sei.fMask=SEE_MASK_NOCLOSEPROCESS;
	sei.lpVerb=_T("runas");
	p=FindExePathEnd(pCL);
	len=p-pCL;
	if (!p || !len) {
		ec=ERROR_FILE_NOT_FOUND;
		goto ret;
	}
	for (;;) {
		NSIS::MemFree(pszExePathBuf);
		if (!(pszExePathBuf=(LPTSTR)NSIS::MemAlloc((++len)*sizeof(TCHAR))))goto dieOOM;
		if (GetModuleFileName(0,pszExePathBuf,len)<len)break;
		len+=MAX_PATH;
	}
	sei.lpFile=pszExePathBuf;	
	len=lstrlen(p);
	len+=20;//space for "/UAC:xxxxxx /NCRC\0"
	if (!(pszParamBuf=(LPTSTR)NSIS::MemAlloc(len*sizeof(TCHAR))))goto dieOOM;
	wsprintf(pszParamBuf,_T("/UAC:%X /NCRC%s"),g.hSrvIPC,p);//NOTE: The argument parser depends on our special flag appearing first
	sei.lpParameters=pszParamBuf;

	if (_AllowSetForegroundWindow) {
		BOOL res=_AllowSetForegroundWindow(ASFW_ANY);
		TRACEF("_AllowSetForegroundWindow ret=%d\n",res);
	}

#ifdef FEAT_CUSTOMRUNASDLG
	if (GetSysVer()>=6 && !SysElevationPresent()) { 
		ec=MyRunAs(g.hInstance,sei);
		/*WTF is this for?>>>if (ec==NO_ERROR || ec==ERROR_CANCELLED)*/
			ShExecRunAs=false;
	}
#endif
	if (ShExecRunAs) {
		ec=(ShellExecuteEx(&sei)?NO_ERROR:GetLastError());
		TRACEF("ForkSelf: ShExec->Runas returned %d hInstApp=%d\n",ec,sei.hInstApp);
	}
	if (ec)goto ret;
	TRACEF("ForkSelf: waiting for process %X (%s|%s)\n",(sei.hProcess),sei.lpFile,sei.lpParameters);
	{
		ASSERT(sei.hProcess);
		ShowWindow(g.hSrvIPC,SW_HIDE);//FUCKO: Is this smart? Will it prevent us from playing focus tricks?
		
		DWORD w=WaitForSingleObject(sei.hProcess,INFINITE);
		if (w==WAIT_OBJECT_0) {
			VERIFY(GetExitCodeProcess(sei.hProcess,&ForkExitCode));
		} 
		else {
			ec=GetLastError();
			TRACEF("ForkSelf:WaitForSingleObject failed ec=%d w=%d\n",ec,w);ASSERT(!"ForkSelf:WaitForSingleObject");
		}		
	}
	TRACEF("ForkSelf: wait complete, ec=%d forkexitcode=%d\n",ec,ForkExitCode);
	goto ret;
dieOOM:
	ec=ERROR_OUTOFMEMORY;
ret:
	StopIPCSrv();
	CloseHandle(sei.hProcess);
	NSIS::MemFree(pszExePathBuf);
	NSIS::MemFree(pszParamBuf);
	return ec;
}


/*** RunElevated
Return:	r0:	Windows error code (0 on success, 1223 if user aborted elevation dialog, anything else should be treated as a fatal error)	
		r1: If r0==0, r1 is:
				0 if UAC is not supported by the OS, 
				1 if UAC was used to elevate and the current process should act like a wrapper (Call Quit in .OnInit without any further processing), 
				2 if the process is running @ HighIL (Member of admin group on other systems),
				3 if you should call RunElevated again (This can happen if a user without admin priv. is used in the runas dialog),
		r2: If r0==0 && r1==1: r2 is the ExitCode of the elevated fork process (The NSIS errlvl is also set to the ExitCode)
		r3: If r0==0: r3 is 1 if the user is a member of the admin group or 0 otherwise
*/
NSISEXPORT(RunElevated   ,hwndNSIS,StrSize,Vars,StackTop,XParams) {
	BYTE UACMode=0;
	bool UserIsAdmin=false;
	DWORD ec=ERROR_ACCESS_DENIED,ForkExitCode;
	TOKEN_ELEVATION_TYPE tet;
	LPTSTR p;
	
	UserIsAdmin=_IsAdmin();
#ifdef BUILD_XPTEST
	if (!UserIsAdmin)goto DbgXPAsUAC;//Skip UAC detection for special debug builds and force a call to runas on <NT6 systems
#endif
	if (!_SupportsUAC() && !SysSupportsRunAs())goto noUAC;
	if ((ec=DelayLoadDlls()))goto ret;
	{	
		p=FindExePathEnd(GetCommandLine());
		while(p && *p==' ')p=CharNext(p);TRACEF("RunElevated,Params=|%s|\n",p);
		if (p && *p++=='/'&&*p++=='U'&&*p++=='A'&&*p++=='C'&&*p++==':') {
			if (ec=DllSelfAddRef())goto ret;
			UACMode=2;
			g.UseIPC=true;
			g.hSrvIPC=(HWND)StrToUInt(p,true);
			ASSERT(IsWindow(g.hSrvIPC));
			if (!IsWindow(g.hSrvIPC))ec=ERRAPP_BADIPCSRV;
			if (!UserIsAdmin) { //Elevation used, but we are not Admin, let the wrapper know so it can try again...		
				UACMode=0xFF;//Special invalid mode
				DWORD_PTR MsgRet;
				if (SendIPCMsg(IPC_ELEVATEAGAIN,0,0,MsgRet) || !MsgRet)ec=ERRAPP_BADIPCSRV;
			}
			goto ret;
		}
	}
	
	if ((ec=DllSelfAddRef()) || (ec=_GetElevationType(&tet)))goto ret;
	if (tet==TokenElevationTypeFull || UserIsAdmin) {
		UserIsAdmin=true;
		UACMode=2;
		goto ret;
	}
	
#ifdef BUILD_XPTEST
DbgXPAsUAC:VERIFY(!DllSelfAddRef());
#endif
	//OS supports UAC and we need to elevate...
	ASSERT(!UserIsAdmin);
	UACMode=1;
	ec=ForkSelf(ForkExitCode,XParams);
	if (!ec && !g.ElevateAgain) {
		SetVarUINT(INST_2,ForkExitCode);
		SetErrLvl(XParams,ForkExitCode);
	}
	goto ret;
noUAC:
	ec=NO_ERROR;ASSERT(UACMode==0);
ret:
	if (ec==ERROR_CANCELLED) {
		if (UACMode!=1)ec=ERROR_INVALID_FUNCTION;
		if (UACMode<2)g.UseIPC=false;
	}
	if (UACMode==0xFF && !ec) {//We called IPC_ELEVATEAGAIN, so we need to quit so the wrapper gains control
		ASSERT(g.UseIPC);
		UACMode=1;//We pretend to be the wrapper so Quit gets called in .OnInit
		SetErrLvl(XParams,0);
		_Unload();
	}
	if (g.ElevateAgain) {
		ASSERT(!g.UseIPC);
		UACMode=3;//Fork called IPC_ELEVATEAGAIN, we need to change our UACMode so the wrapper(our instance) can try to elevate again if it wants to
	}
	if (!g.UseIPC)_Unload();//The wrapper can call quit in .OnInit without calling UAC::Unload, set we do it here
	SetVarUINT(INST_0,ec);
	SetVarUINT(INST_1,UACMode);
	SetVarUINT(INST_3,UserIsAdmin);

	TRACEF("RunElevated returning ec=%X UACMode=%d g.UseIPC=%d g.ElevateAgain=%d\n",ec,UACMode,g.UseIPC,g.ElevateAgain);
}}



/*** GetElevationType
Notes:
		TokenElevationTypeDefault=1	:User is not using a split token (UAC disabled)
		TokenElevationTypeFull=2	:UAC enabled, the process is elevated
		TokenElevationTypeLimited=3	:UAC enabled, the process is not elevated
Return:	r0:	(TOKEN_ELEVATION_TYPE)TokenType, The error flag is set if the function fails and r0==0
*/
NSISEXPORT(GetElevationType   ,hwndNSIS,StrSize,Vars,StackTop,XParams) {
	TOKEN_ELEVATION_TYPE tet=(TOKEN_ELEVATION_TYPE)NULL;//Default to invalid value
	if (MaintainDllSelfRef() || /*!_SupportsUAC() ||*/ _GetElevationType(&tet)) SetErrorFlag(XParams);
	SetVarUINT(INST_0,tet);
}}



/*** SupportsUAC
Notes:	Check if the OS supports UAC (And the user has UAC turned on)
Return:	r0:	(BOOL)Result 
*/
NSISEXPORT4(SupportsUAC   ,hwndNSIS,StrSize,Vars,StackTop) {
	BOOL present=false;
	MaintainDllSelfRef();
	if (_SupportsUAC())present=true;	
	SetVarUINT(INST_0,present);
}}



/*** IsAdmin
Return:	r0:	(BOOL)Result 
*/
NSISEXPORT(IsAdmin   ,hwndNSIS,StrSize,Vars,StackTop,XParams) {
	bool Admin=false;
	DWORD ec;
	if (!(ec=MaintainDllSelfRef())) {
		Admin=_IsAdmin();
		if (ec=GetLastError()) {
			TRACEF("IsAdmin failed with %d\n",ec);
			SetErrorFlag(XParams);
			Admin=false;
		}
	}
	SetVarUINT(INST_0,Admin);
}}



/*** ExecCodeSegment
Notes:	Sets error flag on error
		There is currently no way to transfer state to/from the executed code segment!
		If you use instructions that alter the UI or the stack/variables in the code segment (StrCpy,Push/Pop/Exch,DetailPrint,HideWindow etc.) they will affect the hidden wrapper installer and not "your" installer instance!
*/
NSISEXPORT(ExecCodeSegment   ,hwndNSIS,StrSize,Vars,StackTop,XParams) {
	DWORD ec;
	if (!(ec=DllSelfAddRef())) {//force AddRef since our plugin could be called inside the executed code segment!
		ec=ERROR_INVALID_PARAMETER;
		stack_t* pSI=StackPop();
		if (pSI) {
			BOOL badCh;
			UINT pos=StrToUInt(pSI->text,false,&badCh);
			TRACEF("ExecCodeSegment %d (%s) badinput=%d\n",pos-1,pSI->text,badCh);
			if (!badCh && pos--) {
				if (!g.UseIPC)
					ec=NSIS::ExecuteCodeSegment(XParams,pos);
				else {
					DWORD_PTR MsgRet;
					if (!(ec=SendIPCMsg(IPC_EXECCODESEGMENT,pos,0,MsgRet,INFINITE)))ec=MsgRet-1;
				}
			}
			StackFreeItem(pSI);
		}
	}
	if (ec)SetErrorFlag(XParams);
}}



/*** Unload
Notes:	Call in .OnInstFailed AND .OnInstSuccess !
*/
NSISEXPORT4(Unload   ,hwndNSIS,StrSize,Vars=0,StackTop=0) {
	if (!MaintainDllSelfRef())_Unload(); else ASSERT(!"MaintainDllSelfRef failed in Unload!");
}}



#ifdef _DEBUG
BOOL WINAPI DllMain(HINSTANCE hInst,DWORD ul_reason_for_call,LPVOID lpReserved) {
#else
extern "C" BOOL WINAPI _DllMainCRTStartup(HINSTANCE hInst,ULONG ul_reason_for_call,LPVOID lpReserved) {
#endif
	if (ul_reason_for_call==DLL_PROCESS_ATTACH) {
		TRACEF("************************************ DllMain %u\n",GetCurrentProcessId());
		ASSERT(!_OpenProcessToken && !_EqualSid);
		g.hInstance=hInst;
	}
	DBGONLY(if (ul_reason_for_call==DLL_PROCESS_DETACH)ASSERT(g.DllRef==0));//Make sure we unloaded so we don't lock $pluginsdir
	return TRUE;
}
