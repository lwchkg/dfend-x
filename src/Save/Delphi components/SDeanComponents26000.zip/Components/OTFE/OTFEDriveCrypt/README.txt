Development of this TOTFEDriveCrypt component has been shelved until
SecureStar (makers of DriveCrypt) release driver API details.

Without this information, further development is pretty pointless.


Source code already developed has been placed into the "DO_NOT_USE" beneath
this one in order to eliminate possible confusion between the interim
filenames and TOTFEScramDisk component.

